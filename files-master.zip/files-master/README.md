### Github Tutorial

####1. [How to Host Files on Github](http://www.labnol.org/internet/free-file-hosting-github/29092/)

####2. [Github Gists for Non-Developers](http://www.labnol.org/internet/github-gist-tutorial/28499/)

Append ?raw=true to any file URL on Github to get the direct link.
